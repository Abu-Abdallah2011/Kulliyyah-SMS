<x-app-layout>

   <x-slot name="header">
      <div class="flex items-center justify-between">

    {{-- Left: Heading --}}
    <h2 class="font-semibold text-xl text-gray-800 dark:text-gray-200 leading-tight">
        {{ __('Attendance Record') }}
    </h2>

    {{-- Right: Action Buttons --}}
    @can('isAssistant')
        @php
        $class = $teachers->first()?->class;
        @endphp

        <div class="flex items-center gap-2">

            <a href="{{ url('/attendance') }}">
                <x-primary-button class="bg-green-600 hover:bg-green-700 flex items-center gap-2">
                    <i class="fa-solid fa-pen"></i>
                </x-primary-button>
            </a>

            <a href="{{ url('/attendanceForPreviousTerms') }}">
                <x-primary-button class="bg-yellow-500 hover:bg-yellow-600 flex items-center gap-2">
                    <i class="fa-solid fa-clock-rotate-left"></i>
                </x-primary-button>
            </a>

            <a href="{{ route('attendance.class.pdf', ['class' => $class]) }}">
                <x-primary-button class="bg-indigo-600 hover:bg-indigo-700 flex items-center gap-2 shadow">
                    <i class="fa-solid fa-file-pdf text-red-300"></i>
                </x-primary-button>
            </a>

        </div>
    @endcan

</div>

  </x-slot>
  @if((Auth::user()->can('isAssistant') && Request::is('attendance/show')) || (Auth::user()->can('isAssistant') && Request::is('dashboard/attendance/*')))
  <x-success-status class="mb-4" :status="session('message')" />

  <div class="py-6">

@if (!$teachers->isEmpty())
   @foreach ($teachers as $teacher)
   <div class="bg-white dark:bg-gray-800 overflow-hidden shadow-sm sm:rounded-lg">
      <div class="p-3 text-gray-900 dark:text-gray-100">
      <h1 class="font-bold text-center">{{ $teacher->class }}: {{ $teacher->students->count() }}</h1>
        
      <div class="table-responsive">
      <table class="border-collapse w-full">
         <thead>
            <tr>
               <th class="p-2 md:p-3 font-bold uppercase text-gray-600 border border-gray-300 lg:table-cell">ID</th>
               <th class="p-2 md:p-3 font-bold uppercase text-gray-600 border border-gray-300 lg:table-cell">NAME</th>
                 @php
                     $datesDisplayed = [];
                 @endphp
                 @foreach($attendance as $record)
     
                     @if (!in_array($record->date, $datesDisplayed))
                         <th class="text-center  p-2 md:p-3 lg:p-4 text-gray-600 border border-gray-300 lg:table-cell" style="writing-mode: vertical-rl; transform: rotate(180deg);">{{ $record->date }}</th>
                         @php
                             $datesDisplayed[] = $record->date;
                         @endphp
                     @endif
                 @endforeach
             </tr>
         </thead>
         <tbody>
             @foreach ($teacher->students as $index => $student)
                 <tr class="bg-white lg:hover:bg-gray-100 lg:table-row mb-10 lg:mb-0">
                     <td class="w-full lg:w-auto p-2 md:p-3 lg:p-3 text-gray-800 border border-b lg:table-cell relative lg:static font-bold">{{ $index + 1 }}</td>
                     <td class="w-full lg:w-auto p-2 md:p-3 lg:p-3 text-gray-800 border border-b lg:table-cell relative lg:static font-bold"><a href="{{ url('/attendance/guardian_view/' . $student->id) }}">{{ $student->fullname }}</a></td>
                     @foreach($datesDisplayed as $date)
                         @php
                             $statusesForDate = $attendance->where('date', $date)
                                                         ->where('student_id', $student->id)
                                                         ->pluck('status')
                                                         ->toArray();
                                                        //  echo "Student ID: $student->id, Date: $date, Statuses: " . implode(', ', $statusesForDate) . '<br>';
                         @endphp
                         <td class="text-center w-full lg:w-auto p-2 md:p-3 lg:p-3 text-gray-800 border border-b lg:table-cell relative lg:static font-bold">                           
                             <a href="/attendance/{{$date}}/edit_attendance">
                              @foreach ($statusesForDate as $status)
                              {!! $statusIcons[strtolower($status)] !!}
                                 @endforeach
                              </a>
                         </td>
                     @endforeach
                 </tr>
             @endforeach
         </tbody>
     </table>
      </div>

      </div>
   </div>
   @endforeach
@else
   <p>No teachers found.</p>
@endif
  </div>
  @endif

  @if(Request::is('attendance/guardian_view/*'))
  <x-Guardian-attendance-view 
  :attendance="$attendance" :statusIcons="$statusIcons" :student="$student" :attendanceRecords="$attendanceRecords" />
  @endif

  <div class="mt-6 p-4">
   {{$attendance->Links()}}
</div>

   </x-app-layout>